import os, json
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base, Mapped, mapped_column
from sqlalchemy import Integer, String, Text

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")

# For cloud hosting, set DATABASE_URL to your PostgreSQL connection string.
# Locally, it automatically uses SQLite.
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///school.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="teacher")
    subject: Mapped[str] = mapped_column(String(120), default="")
    assigned_class: Mapped[str] = mapped_column(String(120), default="")

class SchoolData(Base):
    __tablename__ = "school_data"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    data_json: Mapped[str] = mapped_column(Text, default="{}")
    updated_at: Mapped[str] = mapped_column(String(40), default="")

Base.metadata.create_all(engine)

def default_data():
    return {"students": [], "teachers": [], "classes": [], "fees": [], "notices": [],
            "subjects": [], "results": [], "attendanceRecords": []}

def ensure_seed_accounts():
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            admin_email = os.environ.get("ADMIN_EMAIL", "admin@mangowal.school")
            admin_password = os.environ.get("ADMIN_PASSWORD", "Admin123!")
            teacher_email = os.environ.get("TEACHER_EMAIL", "teacher@mangowal.school")
            teacher_password = os.environ.get("TEACHER_PASSWORD", "Teacher123!")
            db.add(User(name="School Admin", email=admin_email.lower(),
                        password_hash=generate_password_hash(admin_password), role="admin"))
            db.add(User(name="Demo Teacher", email=teacher_email.lower(),
                        password_hash=generate_password_hash(teacher_password),
                        role="teacher", subject="", assigned_class=""))
        if db.query(SchoolData).count() == 0:
            db.add(SchoolData(id=1, data_json=json.dumps(default_data()), updated_at=datetime.utcnow().isoformat()))
        db.commit()
    finally:
        db.close()

ensure_seed_accounts()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        db = SessionLocal()
        try:
            user = db.get(User, session["user_id"])
            if not user or user.role != "admin":
                return jsonify({"error": "Administrator permission required."}), 403
        finally:
            db.close()
        return fn(*args, **kwargs)
    return wrapper

def current_user():
    db = SessionLocal()
    try:
        return db.get(User, session.get("user_id"))
    finally:
        db.close()

def load_data():
    db = SessionLocal()
    try:
        row = db.get(SchoolData, 1)
        return json.loads(row.data_json) if row else default_data()
    finally:
        db.close()

def save_data(data):
    db = SessionLocal()
    try:
        row = db.get(SchoolData, 1)
        row.data_json = json.dumps(data)
        row.updated_at = datetime.utcnow().isoformat()
        db.commit()
    finally:
        db.close()

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("index"))
    error = ""
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.email == email).first()
            if user and check_password_hash(user.password_hash, password):
                session.clear()
                session["user_id"] = user.id
                return redirect(url_for("index"))
            error = "Invalid email or password."
        finally:
            db.close()
    return render_template("login.html", error=error)

@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.get("/")
@login_required
def index():
    return render_template("index.html")

@app.get("/api/data")
@login_required
def api_get_data():
    user = current_user()
    return jsonify({
        "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role,
                 "subject": user.subject, "assigned_class": user.assigned_class},
        "data": load_data()
    })

@app.put("/api/data")
@login_required
def api_put_data():
    user = current_user()
    incoming = request.get_json(silent=True)
    if not isinstance(incoming, dict):
        return jsonify({"error": "Invalid data."}), 400
    # The existing frontend sends the complete application object.
    # Admins may replace all school data. Teachers may update attendance/results,
    # but cannot change the administrative collections.
    clean = default_data()
    for key in clean:
        if isinstance(incoming.get(key), list):
            clean[key] = incoming[key]
    if user.role != "admin":
        old = load_data()
        clean["teachers"] = old["teachers"]
        clean["classes"] = old["classes"]
        clean["fees"] = old["fees"]
        clean["notices"] = old["notices"]
        clean["subjects"] = old["subjects"]
        # Restrict teacher changes to their assigned class/subject where possible.
        if user.assigned_class:
            clean["students"] = old["students"]
        if user.subject:
            clean["results"] = [
                r for r in incoming.get("results", [])
                if any(s.get("name","").lower() == user.subject.lower()
                       and s.get("id") == r.get("subjectId") for s in old["subjects"])
            ]
            clean["attendanceRecords"] = [
                r for r in incoming.get("attendanceRecords", [])
                if any(s.get("name","").lower() == user.subject.lower()
                       and s.get("id") == r.get("subjectId") for s in old["subjects"])
            ]
        else:
            clean["results"] = old["results"]
            clean["attendanceRecords"] = old["attendanceRecords"]
    save_data(clean)
    return jsonify({"ok": True})

@app.post("/api/teacher-accounts")
@admin_required
def create_teacher_account():
    body = request.get_json(silent=True) or {}
    name = str(body.get("name","")).strip()
    email = str(body.get("email","")).strip().lower()
    password = str(body.get("password",""))
    subject = str(body.get("subject","")).strip()
    assigned_class = str(body.get("assigned_class","")).strip()
    if len(name) < 2 or "@" not in email or len(password) < 8:
        return jsonify({"error": "Name, valid email and password of at least 8 characters are required."}), 400
    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == email).first():
            return jsonify({"error": "An account with this email already exists."}), 409
        db.add(User(name=name, email=email, password_hash=generate_password_hash(password),
                    role="teacher", subject=subject, assigned_class=assigned_class))
        db.commit()
        return jsonify({"ok": True})
    finally:
        db.close()

@app.get("/api/teacher-accounts")
@admin_required
def list_teacher_accounts():
    db = SessionLocal()
    try:
        users = db.query(User).filter(User.role == "teacher").all()
        return jsonify([{"id":u.id,"name":u.name,"email":u.email,"subject":u.subject,
                        "assigned_class":u.assigned_class} for u in users])
    finally:
        db.close()

@app.delete("/api/teacher-accounts/<int:user_id>")
@admin_required
def delete_teacher_account(user_id):
    db = SessionLocal()
    try:
        user = db.get(User, user_id)
        if not user or user.role != "teacher":
            return jsonify({"error": "Teacher account not found."}), 404
        db.delete(user); db.commit()
        return jsonify({"ok": True})
    finally:
        db.close()

@app.get("/api/health")
def health():
    return jsonify({"status":"ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
