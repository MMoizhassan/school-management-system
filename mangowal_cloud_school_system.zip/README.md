# Govt School Mangowal — Cloud + Teacher Login Version

This version upgrades the supplied single-file school system to a Flask web application with:
- Login page for administrators and teachers
- Secure password hashing
- Separate teacher login accounts
- PostgreSQL support for cloud hosting
- SQLite fallback for local learning/testing
- Cloud-backed school data API
- Existing student, class, attendance, subject, result, fee, notice and backup features

## Run locally on Windows

Open PowerShell in this project folder:

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open:
`http://127.0.0.1:5000`

Development login:
- Admin: `admin@mangowal.school` / `Admin123!`
- Teacher: `teacher@mangowal.school` / `Teacher123!`

Do not use these passwords for a public website.

## Put it on the cloud

1. Create a PostgreSQL database with a cloud provider such as Render Postgres, Neon, Supabase, or another managed PostgreSQL service.
2. Create a web service for this Flask project.
3. Set these environment variables on the hosting service:
   - `DATABASE_URL` = your PostgreSQL connection string
   - `SECRET_KEY` = a long random secret
   - `ADMIN_EMAIL` = your real administrator email
   - `ADMIN_PASSWORD` = a strong administrator password
   - `TEACHER_EMAIL` = an initial teacher email
   - `TEACHER_PASSWORD` = a strong initial teacher password
4. Build command:
   `pip install -r requirements.txt`
5. Start command:
   `gunicorn app:app`
6. Open the public HTTPS URL supplied by your host.

The database tables are created automatically when the application starts.

## Important security note

This is a learning/project version. Before using it for real school records, add CSRF protection, stricter authorization for every operation, audit logs, rate limiting, password reset, HTTPS-only cookies, backups, and granular database CRUD instead of whole-dataset synchronization.
